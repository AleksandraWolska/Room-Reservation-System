package com.reservation.RoomReservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
