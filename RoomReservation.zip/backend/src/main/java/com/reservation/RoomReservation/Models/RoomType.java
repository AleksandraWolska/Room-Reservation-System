package com.reservation.RoomReservation.Models;

public enum RoomType {

    LECTURE_ROOM,
    WORKSHOP,
    COMPUTERS_ROOM,
    CHEMISTRY_LABORATORY,
    OFFICE

}
