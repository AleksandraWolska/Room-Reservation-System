package com.reservation.RoomReservation.Utils.Requests;

import lombok.Data;

import java.time.LocalDate;

@Data
public class TimeRequest {

    private LocalDate date;
}
