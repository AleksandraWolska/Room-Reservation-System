// src/config.ts
export const API_CONFIG = {
    BASE_URL: 'http://localhost:8080', // Replace with your actual server API base URL
  };
  