Aby uruchomić frontend należy:
wydać komendę "npm start" w folderze frontend lub komendę "npm run frontend" w głównym folderze projektu.


Backend:
./mvnw clean install
cd target
java -jar your-application-name.jar
